/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 * Implementa un jugador Minimax con profundización iterativa y poda alfa-beta para el juego Hex.
 */
package edu.upc.epsevg.prop.hex.players;

import edu.upc.epsevg.prop.hex.HexGameStatus;
import edu.upc.epsevg.prop.hex.IAuto;
import edu.upc.epsevg.prop.hex.IPlayer;
import edu.upc.epsevg.prop.hex.PlayerMove;
import edu.upc.epsevg.prop.hex.SearchType;
import java.awt.Point;
import java.util.*;

/**
 * Representa un jugador de Hex que utiliza el algoritmo Minimax con profundización iterativa y poda alfa-beta.
 */
public class MinimaxID implements IPlayer, IAuto {

    private String name;
    private int maxTime;
    private HashMap<String, Integer> transpositionTable;
    private long startTime;
    private long timeLimit;
    
    /**
     * Construye un nuevo jugador Minimax con un nombre especificado y tiempo máximo por movimiento.
     * @param name El nombre del jugador.
     * @param maxTime El tiempo máximo permitido por movimiento, en segundos.
     */
    public MinimaxID(String name, int maxTime) {
        this.name = name;
        this.maxTime = maxTime;
        this.transpositionTable = new HashMap<>();
    }
    
    /**
     * Maneja eventos de tiempo agotado (no utilizado en esta implementación).
     */
    @Override
    public void timeout() {}
    
     /**
     * Ejecuta un movimiento utilizando Minimax con profundización iterativa.
     * @param s El estado actual del juego.
     * @return El mejor movimiento encontrado dentro del tiempo permitido.
     */
    @Override
    public PlayerMove move(HexGameStatus s) {
        Point bestMove = null;
        int bestValue = Integer.MIN_VALUE;
        this.startTime = System.currentTimeMillis();
        this.timeLimit = startTime + (maxTime * 1000); // Convert seconds to milliseconds

        for (int depth = 1; ; depth++) {
            if (System.currentTimeMillis() > timeLimit) break;

            Point currentBestMove = null;
            int currentBestValue = Integer.MIN_VALUE;

            List<Point> possibleMoves = getPossibleMoves(s);
            PriorityQueue<MoveNode> sortedMoves = prioritizeMoves(s, possibleMoves, true);

            for (MoveNode moveNode : sortedMoves) {
                if (System.currentTimeMillis() > timeLimit) break;

                HexGameStatus nextState = cloneGameStatus(s);
                applyMove(nextState, moveNode.getPoint(), true);
                int value = minimax(nextState, depth - 1, Integer.MIN_VALUE, Integer.MAX_VALUE, false);

                if (value > currentBestValue) {
                    currentBestValue = value;
                    currentBestMove = moveNode.getPoint();
                }
            }

            if (currentBestMove != null) {
                bestMove = currentBestMove;
                bestValue = currentBestValue;
            }
        }

        return new PlayerMove(bestMove, System.currentTimeMillis() - startTime, maxTime, SearchType.MINIMAX);
    }

    /**
     * Implementa el algoritmo Minimax con poda alfa-beta.
     * @param state El estado actual del juego.
     * @param depth La profundidad restante de búsqueda.
     * @param alpha El valor alfa para la poda.
     * @param beta El valor beta para la poda.
     * @param isMaximizingPlayer Verdadero si es el turno del jugador maximizador, falso en caso contrario.
     * @return La puntuación evaluada para el estado dado.
     */
    private int minimax(HexGameStatus state, int depth, int alpha, int beta, boolean isMaximizingPlayer) {
        if (depth == 0 || state.isGameOver() || System.currentTimeMillis() > timeLimit) {
            return evaluateState(state);
        }

        String boardKey = state.toString();
        if (transpositionTable.containsKey(boardKey)) {
            return transpositionTable.get(boardKey);
        }

        List<Point> possibleMoves = getPossibleMoves(state);
        PriorityQueue<MoveNode> sortedMoves = prioritizeMoves(state, possibleMoves, isMaximizingPlayer);

        if (isMaximizingPlayer) {
            int maxEval = Integer.MIN_VALUE;
            for (MoveNode moveNode : sortedMoves) {
                if (System.currentTimeMillis() > timeLimit) break;

                HexGameStatus nextState = cloneGameStatus(state);
                applyMove(nextState, moveNode.getPoint(), true);
                int eval = minimax(nextState, depth - 1, alpha, beta, false);
                maxEval = Math.max(maxEval, eval);
                alpha = Math.max(alpha, eval);
                if (beta <= alpha) break;
            }
            transpositionTable.put(boardKey, maxEval);
            return maxEval;
        } else {
            int minEval = Integer.MAX_VALUE;
            for (MoveNode moveNode : sortedMoves) {
                if (System.currentTimeMillis() > timeLimit) break;

                HexGameStatus nextState = cloneGameStatus(state);
                applyMove(nextState, moveNode.getPoint(), false);
                int eval = minimax(nextState, depth - 1, alpha, beta, true);
                minEval = Math.min(minEval, eval);
                beta = Math.min(beta, eval);
                if (beta <= alpha) break;
            }
            transpositionTable.put(boardKey, minEval);
            return minEval;
        }
    }

    /**
     * Evalúa el estado actual del juego.
     * @param state El estado actual del juego.
     * @return La puntuación heurística del estado.
     */
    private int evaluateState(HexGameStatus state) {
        int player = 1;
        int opponent = 2;

        // Si algún jugador ya ganó, retornamos valores extremos.
        if (isWinning(state, player)) return Integer.MAX_VALUE;
        if (isWinning(state, opponent)) return Integer.MIN_VALUE;

        // Distancias heurísticas.
        int playerDistance = dijkstraVerticalDistance(state, player);
        int opponentDistance = dijkstraHorizontalDistance(state, opponent);

        // Bloquear al oponente tiene un impacto significativo.
        int blockScore = blockOpponentHeuristic(state, opponent);

        // La heurística general combina la distancia del jugador con la penalización por permitir al oponente acercarse.
        return (1000 - playerDistance) - (1000 - opponentDistance) + blockScore;
    }

    /**
     * Calcula la distancia mínima desde el borde superior hasta el inferior para un jugador.
     * Utiliza el algoritmo de Dijkstra para encontrar el camino más corto.
     * @param state El estado actual del juego.
     * @param player El jugador para el que se calcula la distancia.
     * @return La distancia mínima en términos de peso del camino.
     */
    private int dijkstraVerticalDistance(HexGameStatus state, int player) {
        int size = state.getSize();
        int[][] distances = new int[size][size];
        boolean[][] visited = new boolean[size][size];
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, 1}, {1, -1}};

        for (int i = 0; i < size; i++) {
            Arrays.fill(distances[i], Integer.MAX_VALUE);
        }

        PriorityQueue<Point> queue = new PriorityQueue<>(Comparator.comparingInt(p -> distances[p.x][p.y]));

        for (int i = 0; i < size; i++) {
            distances[0][i] = 0;
            queue.add(new Point(0, i));
        }

        while (!queue.isEmpty()) {
            Point current = queue.poll();
            int cx = current.x, cy = current.y;
            if (visited[cx][cy]) continue;
            visited[cx][cy] = true;

            for (int[] dir : directions) {
                int nx = cx + dir[0], ny = cy + dir[1];
                if (nx >= 0 && nx < size && ny >= 0 && ny < size && !visited[nx][ny]) {
                    int cost = (state.getPos(nx, ny) == player || state.getPos(nx, ny) == 0) ? 1 : 1000;
                    if (distances[cx][cy] + cost < distances[nx][ny]) {
                        distances[nx][ny] = distances[cx][cy] + cost;
                        queue.add(new Point(nx, ny));
                    }
                }
            }
        }

        int minDistance = Integer.MAX_VALUE;
        for (int i = 0; i < size; i++) {
            minDistance = Math.min(minDistance, distances[size - 1][i]);
        }
        return minDistance;
    }

     /**
     * Calcula la distancia mínima desde el borde izquierdo hasta el derecho para el oponente.
     * Utiliza el algoritmo de Dijkstra para encontrar el camino más corto.
     * @param state El estado actual del juego.
     * @param opponent El oponente para el que se calcula la distancia.
     * @return La distancia mínima en términos de peso del camino.
     */
    private int dijkstraHorizontalDistance(HexGameStatus state, int opponent) {
        int size = state.getSize();
        int[][] distances = new int[size][size];
        boolean[][] visited = new boolean[size][size];
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, 1}, {1, -1}};

        for (int i = 0; i < size; i++) {
            Arrays.fill(distances[i], Integer.MAX_VALUE);
        }

        PriorityQueue<Point> queue = new PriorityQueue<>(Comparator.comparingInt(p -> distances[p.x][p.y]));

        for (int i = 0; i < size; i++) {
            distances[i][0] = 0;
            queue.add(new Point(i, 0));
        }

        while (!queue.isEmpty()) {
            Point current = queue.poll();
            int cx = current.x, cy = current.y;
            if (visited[cx][cy]) continue;
            visited[cx][cy] = true;

            for (int[] dir : directions) {
                int nx = cx + dir[0], ny = cy + dir[1];
                if (nx >= 0 && nx < size && ny >= 0 && ny < size && !visited[nx][ny]) {
                    int cost = (state.getPos(nx, ny) == opponent || state.getPos(nx, ny) == 0) ? 1 : 1000;
                    if (distances[cx][cy] + cost < distances[nx][ny]) {
                        distances[nx][ny] = distances[cx][cy] + cost;
                        queue.add(new Point(nx, ny));
                    }
                }
            }
        }

        int minDistance = Integer.MAX_VALUE;
        for (int i = 0; i < size; i++) {
            minDistance = Math.min(minDistance, distances[i][size - 1]);
        }
        return minDistance;
    }

    /**
     * Verifica si un jugador ha ganado.
     * @param state El estado actual del juego.
     * @param player El jugador a verificar.
     * @return Verdadero si el jugador ha ganado, falso en caso contrario.
     */
    private boolean isWinning(HexGameStatus state, int player) {
        int size = state.getSize();
        boolean[][] visited = new boolean[size][size];
        Queue<Point> queue = new LinkedList<>();

        if (player == 1) {
            for (int i = 0; i < size; i++) {
                if (state.getPos(0, i) == player) {
                    queue.add(new Point(0, i));
                }
            }
        } else {
            for (int i = 0; i < size; i++) {
                if (state.getPos(i, 0) == player) {
                    queue.add(new Point(i, 0));
                }
            }
        }

        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, 1}, {1, -1}};

        while (!queue.isEmpty()) {
            Point current = queue.poll();
            int x = current.x, y = current.y;
            if ((player == 1 && x == size - 1) || (player == 2 && y == size - 1)) {
                return true;
            }

            for (int[] dir : directions) {
                int nx = x + dir[0], ny = y + dir[1];
                if (nx >= 0 && nx < size && ny >= 0 && ny < size && !visited[nx][ny] && state.getPos(nx, ny) == player) {
                    visited[nx][ny] = true;
                    queue.add(new Point(nx, ny));
                }
            }
        }
        return false;
    }

     /**
     * Calcula el valor heurístico para bloquear al oponente.
     * @param state El estado actual del juego.
     * @param opponent El ID del oponente.
     * @return El valor heurístico del bloqueo.
     */
    private int blockOpponentHeuristic(HexGameStatus state, int opponent) {
        int size = state.getSize();
        int score = 0;
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, 1}, {1, -1}};

        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                if (state.getPos(x, y) == 0) {
                    for (int[] dir : directions) {
                        int nx = x + dir[0], ny = y + dir[1];
                        if (nx >= 0 && nx < size && ny >= 0 && ny < size && state.getPos(nx, ny) == opponent) {
                            score += 25;
                        }
                    }
                }
            }
        }
        return score;
    }

    /**
     * Prioriza los movimientos según la evaluación heurística.
     * @param state El estado actual del juego.
     * @param moves La lista de movimientos posibles.
     * @param isMaximizing Verdadero si es el turno del jugador maximizador, falso en caso contrario.
     * @return Una cola priorizada de movimientos.
     */
    private PriorityQueue<MoveNode> prioritizeMoves(HexGameStatus state, List<Point> moves, boolean isMaximizing) {
        Comparator<MoveNode> comparator = isMaximizing ? (a, b) -> Integer.compare(b.getValue(), a.getValue()) : (a, b) -> Integer.compare(a.getValue(), b.getValue());
        PriorityQueue<MoveNode> sortedMoves = new PriorityQueue<>(comparator);

        for (Point move : moves) {
            HexGameStatus tempState = cloneGameStatus(state);
            applyMove(tempState, move, isMaximizing);
            int value = evaluateState(tempState);
            int neighborsFactor = countNeighbors(state, move, isMaximizing ? 1 : 2);
            sortedMoves.add(new MoveNode(move, value + neighborsFactor));
        }

        return sortedMoves;
    }

    private int countNeighbors(HexGameStatus state, Point move, int player) {
        int size = state.getSize();
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, 1}, {1, -1}};
        int count = 0;
        for (int[] dir : directions) {
            int nx = move.x + dir[0], ny = move.y + dir[1];
            if (nx >= 0 && nx < size && ny >= 0 && ny < size && state.getPos(nx, ny) == player) {
                count++;
            }
        }
        return count;
    }

    private List<Point> getPossibleMoves(HexGameStatus state) {
        List<Point> moves = new ArrayList<>();
        for (int x = 0; x < state.getSize(); x++) {
            for (int y = 0; y < state.getSize(); y++) {
                if (state.getPos(x, y) == 0) {
                    moves.add(new Point(x, y));
                }
            }
        }
        return moves;
    }

    /**
     * Clona el estado actual del juego.
     * @param original El estado original del juego.
     * @return Un clon del estado del juego.
     */

    private HexGameStatus cloneGameStatus(HexGameStatus original) {
        HexGameStatus copy = new HexGameStatus(original.getSize());
        for (int x = 0; x < original.getSize(); x++) {
            for (int y = 0; y < original.getSize(); y++) {
                if (original.getPos(x, y) != 0) {
                    copy.placeStone(new Point(x, y));
                }
            }
        }
        return copy;
    }

    /**
     * Aplica un movimiento al estado del juego.
     * @param state El estado del juego.
     * @param move El movimiento a aplicar.
     * @param isPlayer Verdadero si el movimiento es realizado por el jugador, falso en caso contrario.
     */

    private void applyMove(HexGameStatus state, Point move, boolean isPlayer) {
        state.placeStone(move);
    }

    @Override
    public String getName() {
        return "Minimax(" + name + ")";
    }

    private static class MoveNode {
        private final Point point;
        private final int value;

        public MoveNode(Point point, int value) {
            this.point = point;
            this.value = value;
        }

        public Point getPoint() {
            return point;
        }

        public int getValue() {
            return value;
        }
    }
}
